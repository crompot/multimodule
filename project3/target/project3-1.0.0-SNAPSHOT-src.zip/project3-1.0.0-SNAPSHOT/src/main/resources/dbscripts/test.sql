select *from table;
